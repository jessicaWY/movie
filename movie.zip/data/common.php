<?php
$host='127.0.0.1';
$aname='root';
$apwd='';
$dbname='shangyingla';
$port=3306;